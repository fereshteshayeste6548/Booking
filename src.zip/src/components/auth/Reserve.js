import React from 'react';

const Ticket = ({ reservation }) => {
  return (
    <div className="ticket">
      <h3>Ticket Information</h3>
      <p>Origin: {reservation.origin}</p>
      <p>Destination: {reservation.destination}</p>
      <p>Departure Date: {reservation.departure_date}</p>
      <p>Departure Time: {reservation.departure_time}</p>
      <p>Passenger First Name: {reservation.passenger_FirstName}</p>
      <p>Passenger Last Name: {reservation.passenger_LastName}</p>
      <p>Passenger Sex: {reservation.passenger_sex}</p>
      <p>Passenger Email: {reservation.passenger_email}</p>
      <p>Passenger Birthdate: {reservation.passenger_birthdate}</p>
      <p>Passenger SSID: {reservation.passenger_ssid}</p>
      <p>Ticket Price: {reservation.ticket_price}</p>
    </div>
  );
};

export default Ticket;
