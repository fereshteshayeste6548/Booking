import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import "./Login.css";
import { useNavigate } from 'react-router-dom';
import { DataAppContext } from '../DataApp';

const Login = () => {
  const navigate = useNavigate();
  const localContext = useContext(DataAppContext);
  const { appState, setAppState } = localContext;
  const { loginStatus } = appState;

  const initialData = {
    email: '',
    password: '',
  };

  const [loginformdata, setFormdata] = useState(initialData);
  const [loginstatus, setStatus] = useState(false);

  const updateData = (e) => {
    let tempObj = {};
    tempObj[e.target.id] = e.target.value.trim();
    setFormdata({ ...loginformdata, ...tempObj });
  };

  const loginFn = async () => {
    if (!loginformdata.email || !loginformdata.password) {
      alert("Please fill in all the fields");
      return;
    }

    try {
      const response = await fetch("http://127.0.0.1:8000/api/token/", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: loginformdata.email,
          password: loginformdata.password,
        }),
      });

      if (response.ok) {
        setStatus(true);
        setAppState({
          ...appState,
          loginStatus: true,
          email: loginformdata.email,
        });
        navigate('/');
      } else {
        console.error('Login API request failed:', response.statusText);
        alert("Invalid email or password");
      }
    } catch (error) {
      console.error('Error sending login request:', error);
    }

    setFormdata(initialData);
  };

  useEffect(() => {
    let temp = localStorage.getItem('users');
    console.log(JSON.parse(temp));
  }, [loginstatus]);

  return (
    <div className='login'>
      <div className='login__conatainer'>
        <div className='login__img'>
          <img src='https://imgak.mmtcdn.com/pwa_v3/pwa_hotel_assets/header/logo@2x.png' alt=''/>
        </div>
        <h3>Login Form</h3>
        <input type="email" id="email" onChange={updateData} value={loginformdata.email} placeholder="Enter Email" autoComplete="off" />
        <input type="password" id="password" onChange={updateData} value={loginformdata.password} placeholder="Enter Password" />
        <br></br>
        <button className='btn' onClick={loginFn}>Login</button>
        <br></br>
        <Link to="/register">Register</Link>
        {loginstatus && <div className="alert alert-success" role="alert">
          <p>Logged In Successfully</p>
        </div>}
      </div>
    </div>
  );
}

export default Login;
