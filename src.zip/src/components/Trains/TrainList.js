import React, { useEffect, useState } from 'react';
import "./TrainList.css";
import TCard from './TCard';
import "../Home.css";
import THome from './THome';


function TrainList() {

  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [depart, setDepart] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [numOfPassengers, setNumOfPassengers] = useState(1);
  const [travelType, setTravelType] = useState("one-way");

  const [trains, setTrains] = useState([]);
  const [filteredTrains, setFilteredTrains] = useState([]);

  const getData = async () => {
    await fetch(
      "http://127.0.0.1:8000/api/train/"
    )
      .then((response) => response.json())
      .then((data) => {
        setFilteredTrains(data);
        setTrains(data);
      });
  };

  useEffect(() => {
    getData();
  }, []);


  return (
    <>
    <THome
      from={from}
      setFrom={setFrom}
      to={to}
      setTo={setTo}
      depart={depart}
      setDepart={setDepart}
      returnDate={returnDate}
      setReturnDate={setReturnDate}
      numOfPassengers={numOfPassengers}
      setNumOfPassengers={setNumOfPassengers}
      travelType={travelType}
      setTravelType={setTravelType}
      trainsProps={trains}
      setFilteredTrains={setFilteredTrains}
    />
    <div className='train__container'>
      <div className='train'>
        <h3>Available Tickets</h3>
        <div className='train__cards'>
          <TCard
            setTrains={setTrains}
            filteredTrains={filteredTrains}
            setFilteredTrains={setFilteredTrains}
          />
        </div>
      </div>

    </div>
    </>
  )
}

export default TrainList;
