import React from 'react'
import "./TCard.css"
import TrainIcon from '@mui/icons-material/Train';
import { Link } from 'react-router-dom';

function TCard({ 
  
  filteredTrains,
  

}) {
  return (
    <div className='card__container'>
      {filteredTrains &&
        filteredTrains.map((train, index) => (

          <div className='card'>
            <div className='card__info'>
            <div className='row1'>
            <p>Train No: <span>{train ? train.train_number : ""}</span></p>
            </div>
              <div className='row1'>
                <p>from:  <span>{train ? train.departure_station : ""}</span></p>
                <p>to: <span>{train ? train.arrival_station : ""}</span></p>
             
              </div>
              <div className='row2'>
              
                <p>Date: <span>{train ? train.departure_date : ""}</span></p>
                <p>departure: <span>{train ? train.departure_time : ""}</span></p>
                
              </div>
              <div className='row3'>
               
                <p>Price: <span>{train ? train.ticket_price : ""}</span></p>
                <p>Availabke seats: <span>{train ? train.available_seats : ""}</span></p>
                
               
              </div>
            </div>
            <div className='card__btn'><Link to="/book">Book</Link></div>
          </div>
          ))}
    </div>
  )
}

export default TCard