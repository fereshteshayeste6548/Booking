import React, { useState , useEffect } from "react";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import "./FTicket.css"
function FTicket() {
  const navigate = useNavigate();
  
  const [flightTicket, setFlightTicket] = useState([])
  const [ticket , setTicket] = useState([
    {
        id: '',
        origin: "",
        destination: "",
        departure_date: "",
        departure_time: "",
        passenger_FirstName: "",
        passenger_LastName: "",
        passenger_sex: "",
        passenger_email: "",
        passenger_birthdate: "",
        passenger_ssid: "",
        ticket_price: "",
        user: '',
        airplane: ''
    },
  ])
  const [dob, setDob] = useState(null);
  
  
    
  const fetchData = async () => {
    try {
      const response = await fetch(
        
        "http://127.0.0.1:8000/api/airplaneticket/"
      );
      const data = await response.json();
      let options = data.map(ticket => ticket.origin)
      const options2 = data.map(ticket => ticket.destination)

      options.push(...options2)

      setFlightTicket(options);
      setTicket(data);
      console.log(data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  

  const handleFormSubmit = (event) => {
    event.preventDefault();
    let data = [...flightsProps];
    let result = data.filter(
      (data) => (data.phoneNumber === phoneNumber || phoneNumber === "") && (data.destination === nationalCode || nationalCode === "")
    );
    setFilteredFlights(result);
  };

}
export default FTicket;