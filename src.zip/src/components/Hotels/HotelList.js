import React, { useEffect, useState } from 'react';
import "./HotelList.css";
import HCard from './HCard';
import HHome from "./HHome";

function HotelList() {
  const [from, setfrom] = useState("");
  const [hotels, setHotels] = useState([]);
  const [filteredHotels, setFilteredHotels] = useState([]);
  const [numOfPeople, setNumOfPeople] = useState(1);

  const getData = async () => {
    await fetch(
      ""
    )
      .then((response) => response.json())
      .then((data) => {
        setFilteredHotels(data);
        setHotels(data);
      });
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <>
      <HHome
        from={from}
        setfrom={setfrom}
        numOfPeople={numOfPeople}
        setNumOfPeople={setNumOfPeople}
        hotelsProps={hotels}
        setFilteredHotels={setFilteredHotels}
      />

      <div className='flight__container'>
        <div className='flight'>
          <h3>Tickets</h3>
          <div className='flight__cards'>
            <HCard
              from={from}
              hotels={hotels}
              setHotels={setHotels}
              filteredHotels={filteredHotels}
              setFilteredHotels={setFilteredHotels}
              numOfPeople={numOfPeople}
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default HotelList;
